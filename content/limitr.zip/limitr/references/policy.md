# Policy reference

Every type in a Limitr policy, its fields, and their defaults. The source of truth is `src/spec/*.stof` in the
Limitr repo. `!` marks a field that can't be null. Number fields typed `float | str` accept Stof units in a string
(`'2GB'`, `'30s'`). Durations (`ms`) accept Stof time units (`30days`, `10min`).

## Limitr (the policy)

| Field | Type | Default | Notes |
|---|---|---|---|
| `version` | ver | engine version | Set by the engine (0.8.0). |
| `credits` | obj | `{}` | Credit name -> `Credit`. |
| `plans` | obj | `{}` | Plan name -> `Plan`. |
| `rules` | obj | `{}` | Rule name -> `Rule`: changes on top of a plan for the customers that have them. |
| `exchange` | Exchange | `{}` | Currency conversion and grant strategy. |
| `notifications` | Notifications | `{}` | Notification name -> `Notification`. |
| `customers` | obj | `{}` | Customer ID -> `Customer` (engine state). |
| `alt_customer_ids` | obj | `{}` | Alt ID -> customer ID (engine state). |
| `capabilities` | obj | `{}` | Capability name -> `Capability`. |
| `estimates` | obj | `{}` | `<entitlement>.<segment>` -> `Estimate` (policy-wide). |
| `estimate_min_samples` | int | 5 | A customer's own estimate is used from this many samples. |
| `hold_ttl` | ms | `10min` | How long an unsettled reservation holds room. |

## Credit

| Field | Type | Default | Notes |
|---|---|---|---|
| `unit` | str! | `'credit'` | Singular unit name. |
| `label` | str! | `'Credit'` | Human-facing name. |
| `description` | str | `''` | |
| `resets` | bool | false | Informational: whether usage of this credit resets. |
| `overhead_cost` | float | 0 | Your provider cost per unit, in runes. Must be >= 0. |
| `pricing_model` | str! | `'flat'` | `flat`, `tiered`, `volume`, or `stairstep`. |
| `price` | Price | null | Flat price per unit. Must be null for the other models. |
| `tiers` | list | null | `PriceTier`s for tiered, volume, and stairstep. Sorted and checked by `valid()`. |
| `stof_units` | str! | `'float'` | Stof units meters keep (Ex. `'MB'`, `'s'`). `'float'` means no conversion. |

Function: `overhead(units: float, context?: obj) -> float`, the provider overhead in runes for `units` (default
`units * overhead_cost`). Override it in the policy for per-call or changing costs. Pricing helpers (used by the
engine): `priced()`, `total_price(n)`, `price_of(quantity, offset)`, `quantity_for(runes, offset)`, `band(n)`.

Pricing models, over billable units (past the limit):

- `flat`: one rate per unit.
- `tiered`: each band's units at that band's rate (like tax brackets).
- `volume`: the band the total falls in sets one rate for all units.
- `stairstep`: a flat fee per band, by the band the total falls in.

## Price and PriceTier

```stof
price: { amount: 0.00002, id: 'price_123' }       // amount in runes, id optional (Ex. a Stripe price)
tiers: [
    { up_to: 100_000, price: { amount: 0.00002 } },
    { up_to: 1_000_000, price: { amount: 0.000015 } },
    { price: { amount: 0.00001 } }                  // no up_to: the last band
]
```

## Exchange and ExchangePair

```stof
exchange: {
    grant_strategy: 'expires_first'   // 'expires_first', 'cheapest_first', or 'valuable_first'
    rune: {}                          // built in: 1 rune
    usd: { value: 1, currency: 'rune' } // built in
    euro: { value: 1.14, currency: 'usd' }
    partner_credit: { value: 0.5, currency: 'ai_token' }   // can map onto a priced credit
}
```

A pair says one unit is `value` units of `currency`. Conversions follow pairs until `rune`, or until a priced credit
(which converts through its price). `valid()` rejects pairs that can't reach runes. At runtime,
`set_exchange_pair(name, value, currency)` adds or replaces a pair (refused, with nothing changed, if it doesn't reach
runes) and `remove_exchange_pair(name)` removes one. `get_pair(c)` is the lookup, so a policy can also override it
for live rates.

## Plan

| Field | Type | Default | Notes |
|---|---|---|---|
| `name` | str | field name | Filled by the engine. |
| `label` | str! | `''` | |
| `period` | str! | `'monthly'` | `yearly`, `monthly`, `weekly`, or `daily` (billing period). |
| `subscription` | str! | `'subscription'` | Entitlement used by `ensure_plan_subscription`. |
| `trial_period` | float, str | null | Delay before `ensure_plan_subscription` charges (Ex. `14days`). |
| `entitlements` | obj! | `{}` | Entitlement name -> `Entitlement`. |
| `topups` | obj! | `{}` | Topup name -> `Topup`. |
| `hidden` | bool | false | Hide from pricing pages. |
| `default` | bool | false | Used when a customer is created without a plan. |

## Rule

A named set of changes on top of a plan, for the customers that have it (`Customer.rules`). The same shapes a
customer's own changes have. No customers or dates of its own: whoever assigns it decides who and when.

| Field | Type | Default | Notes |
|---|---|---|---|
| `name` | str | field name | Filled by the engine. Can't contain a colon. |
| `label` | str! | `''` | |
| `priority` | int! | 0 | When two of a customer's rules set the same thing, higher wins; ties go to the policy's order. |
| `given` | obj | null | Entitlement -> `{ plan? }` (as `give_entitlement`). No `expires_on`. |
| `taken` | obj | null | Entitlement -> `{}` (as `take_entitlement`). No `expires_on`. |
| `overrides` | obj | null | Entitlement -> `Limit` in place of the plan's. No `override_expires_on`. |
| `caps` | obj | null | Cap name -> `Cap`. Each customer keeps its own usage as `rule:<rule>:<cap>` in `caps`. No `expires_on`. |
| `prices` | obj | null | `'credit:<name>'` or `'topup:<name>'` -> price override, for Limitr Cloud's invoices (the engine doesn't read it). |

## Entitlement

| Field | Type | Default | Notes |
|---|---|---|---|
| `description` | str | `''` | |
| `limit` | Limit | null | No limit: a feature flag. |
| `scope` | str | null | Meter on the nearest customer of this type through refs (Ex. `'org'`). |
| `hidden` | bool | false | |
| `enabled` | bool, fn | (absent) | Whether it's on for a call, after plan, gives, and takes. Absent: on. A bool: everyone (`false` is a kill switch). A function `(customer: Customer, entitlement: str, context?: obj) -> bool`, inline (`fn enabled`) or a field pointing at a shared one (`enabled: <Rollouts>.x`). Only narrows; gates usage only; failing is off. |
| `track` | bool | false | Send `feature-checked` each time it's checked (`check`, `allow`, `features`). |
| `estimate_basis` | str | null | Event data field a call's size depends on (Ex. `'input'`). Estimates learn a fixed amount per call plus an amount per unit of it. Same in every plan. |
| `estimate_segment` | str | null | Event data field that picks the estimate segment (Ex. `'model'`). Keep its values few. |

## Limit

| Field | Type | Default | Notes |
|---|---|---|---|
| `credit` | str! | `''` | Required. A credit name. |
| `mode` | str! | `'hard'` | `hard` (deny), `soft` (allow, overage billed), `observe` (never deny). |
| `value` | float, str | 0 | The limit, in the credit's units. |
| `increment` | float, str | 1 | Step for `increment()` / `decrement()`. |
| `minimum` | float, str | null | Floor for the meter. |
| `hard_trailing` | bool! | false | Hard only: allow while the meter is under the limit before the call. |
| `grants_apply` | bool | true | Grants may cover overage. Set false on governors and pure control limits. |
| `resets` | bool | false | Reset the meter each period. A `reset_sch` turns it on. |
| `reset_inc` | ms | null | Period length. 30 days when `resets` and no `reset_sch`. |
| `reset_sch` | str | null | UTC calendar schedule, or `'period'` for each billing period (exclusive with `reset_inc`). |
| `override_expires_on` | ms | null | Customer overrides only. |
| `governor_enabled` | bool | false | Token-bucket rate limit below a hard limit. |
| `governor_capacity` | float, str | null | Bucket size (burst). Required with a governor. |
| `governor_refill_rate` | float | null | Tokens per ms. Required with a governor. |
| `ewma_alpha` | float | 0.2 | Smoothing for the rate trend (0 to 1). |

Schedules: `monthly:N` (day N), `monthly:last`, `weekly:mon`, `nth_weekday:N:mon` (Ex. second Tuesday),
`yearly:M-D`, `quarterly:D`.

## Topup

| Field | Type | Default | Notes |
|---|---|---|---|
| `credit` | str! | `''` | Credit granted. |
| `value` | float, str | 0 | Amount granted. |
| `price` | Price | null | What the topup costs. |
| `description` | str | `''` | |
| `included` | bool | false | Granted automatically with the plan. |
| `included_scopes` | list | null | Customer types it is included for (null: all). |
| `plan_change` | str | `'top_up'` | Included topups, when a customer moves to this plan: `top_up` raises the balance in this credit to `value` and never lowers it, `replace` starts over at `value`, `keep` leaves it until the next reset. |
| `resets` | bool | false | Refill the grant each period. |
| `reset_inc` / `reset_sch` | ms / str | null | As on Limit. |
| `reset_mode` | str | `'hard'` | `hard` (back to value), `add` (add value), `rollover` (carry, then add). |
| `rollover_min` / `rollover_max` | float, str | null | Clamp the carried balance. |
| `rollover_pct` | float | null | Fraction of the balance carried. |
| `max_balance` | float, str | null | Ceiling after a reset. |
| `expires_after` | ms | null | Grant expires this long after purchase. |
| `reset_catchup_cap` | int | null | Max periods to catch up at once. |

## Customer (engine state)

| Field | Type | Notes |
|---|---|---|
| `id` | str! | Primary ID. |
| `plan` | str! | Plan name ('' to inherit from refs). |
| `type` | str! | Default `'user'` (Ex. org, team, seat). |
| `label` | str! | Default `'User'`. |
| `alt_ids` | list! | Other IDs that resolve to this customer. |
| `refs` | list! | IDs of related customers (Ex. a user's team and org). |
| `meters` | obj! | Entitlement -> `Meter`. |
| `overrides` | obj! | Entitlement -> `Limit`. |
| `given` | obj | Entitlement -> `{ plan, expires_on }`: given on top of the plan (`give_entitlement`). Null until the first. |
| `taken` | obj | Entitlement -> `{ expires_on }`: taken even though the plan has it (`take_entitlement`). Null until the first. |
| `rules` | list | Rule names that apply (`set_customer_rules`; Cloud sets them from contracts). Unknown names are skipped. Null when none. |
| `grants` | obj! | Grant ID -> `Grant`. |
| `caps` | obj! | Cap ID -> `Cap`. |
| `metadata` | obj | Anything. `limitr_voucher*` fields are used by Cloud vouchers. |
| `period_start` / `period_end` | ms | The billing period `'period'` schedules follow (Cloud sets them; `set_customer_period`). Null: the plan's calendar period. |

## Meter (engine state)

| Field | Type | Notes |
|---|---|---|
| `credit` | str! | Credit metered. |
| `started` | ms | Start of the current period. |
| `value` | float | Usage this period, in the credit's units. |
| `overhead` | float | Provider overhead this period, in runes (null on meters from before 0.7.0). |
| `holds` | map | Hold ID -> map of `value`, `overhead`, `expires`, `basis`, `segment`. |
| `estimates` | obj | Segment -> `Estimate` for this customer. |
| `history` | list! | Last 3 `{ ts, delta }` entries, for rate and acceleration. |
| `ewma_rate` | float | Smoothed rate. |
| `governor_tokens`, `governor_last_refill` | | Governor state, created on first use. |

## Grant (engine state)

`id`, `credit`, `topup` (name, when from a topup), `plan` (whose topup), `created_on`, `granted_on`,
`starting_value`, `value` (balance), `expires_on`, and the reset fields copied from the topup (`resets`, `reset_inc`,
`reset_sch`, `last_reset`, `reset_mode`, `rollover_*`, `max_balance`, `reset_catchup_cap`). Topup grants follow their
topup's definition: when the plan's topup changes, its grants change too, and when it is removed, its grants are
removed. On a plan change, purchased grants stay, and included grants carry into the new plan's included topup in
the same credit by its `plan_change` (included grants nothing takes over are removed).

## Cap

| Field | Type | Default | Notes |
|---|---|---|---|
| `id` | str! | generated | Key in `customer.caps`. |
| `credit` | str! | `'rune'` | Currency or credit of the ceiling. |
| `value` | float, str | 0 | The ceiling (and the threshold for `cap-threshold-crossed`). |
| `exchangeable` | bool! | true (rune) | Convert other credits through the exchange. False: exact credit only. |
| `overage_only` | bool! | false | Only usage past included plan limits counts. |
| `ignore_grants` | bool! | false | Usage covered by grants doesn't count. |
| `observe_only` | bool! | false | Never deny, only accumulate and notify. |
| `overhead_cost` | bool! | false | Count provider overhead instead of spend. |
| `follow_decrements` | bool! | false | Decrements reduce the cap's meter. |
| `hard_trailing` | bool! | false | Allow while under before the call; deny after the crossing. |
| `shared` | bool! | false | Also applies to customers referencing the holder. |
| `shared_with` | list | null | Caller types a shared cap applies to. |
| `scope` | list | null | Entitlement names it applies to (null: all convertible). |
| `meter_value` | float | 0 | Consumption so far, in the cap's credit. |
| `resets` / `reset_inc` / `reset_sch` | | | As on Limit. Resets zero `meter_value`. |
| `expires_on` | ms | null | The cap is removed after this. |

## Estimate

| Field | Type | Default | Notes |
|---|---|---|---|
| `samples` | int | 0 | Observations (or the weight of a seeded prior). |
| `alpha` | float | 0.1 | Smoothing once there are 1/alpha samples. |
| `per_basis` | bool | false | Learned against a basis. Follows the entitlement's `estimate_basis`; a change starts the estimate over. |
| `value_mean` / `value_var` | float | 0 | Per call, credit units. |
| `overhead_mean` / `overhead_var` | float | 0 | Per call, runes. |
| `basis_mean` / `basis_var` | float | 0 | Per call, the basis (per_basis only). |
| `value_cov` / `overhead_cov` | float | 0 | How value and overhead move with the basis (per_basis only). |

With a basis, predictions follow a line: `value_mean + (value_cov / basis_var) * (basis - basis_mean)`, with the
variance the line doesn't explain. Until there are `<Estimate>.FIT_SAMPLES` (5) calls whose bases differ by
`<Estimate>.FIT_SPREAD` (standard deviation over mean, 0.1), the average call is scaled by `basis / basis_mean`
instead. `fitted()` says which one is in use. A Cloud seed for a per-basis estimate sets the basis fields too.
| `source` | str | `'local'` | `'cloud'` when seeded or pooled by Limitr Cloud. |
| `updated` | ms | null | Last observation. |

Segment keys replace `.` and spaces with `_` (`'claude-sonnet-4.5'` is stored as `claude-sonnet-4_5`). No segment is
`all`.

## Notification

An object under `policy.notifications`:

```stof
notifications: {
    low_balance: {
        fn matches(type: str, event: obj) -> bool { type == 'meter-changed' && event.remaining < 100 }
        fn fire(event: obj) { /* or fire(name: str, event: obj), or fire() */ }
    }
}
```

`fire` may be async. Without `fire`, a match sends the event again under the notification's name (Ex.
`low_balance`), which hosts can subscribe to.

## Capability

Named, access-controlled functions in the policy, for the host app, other services, and AI tools: `name`,
`description`, `version`, `parameters` (list of `{ name, description, schema_type, required }`), `input`, `output`,
`result`, and optional `plans` / `customers` access filters. `#[run]` functions read `self.input` and write
`self.output`; they can call any engine function on `root.policy`, host functions, and `Http::fetch` for hosts the
app allows (Ex. load provider rates into credits). Steps run in order (`#[run(N)]` numbers, then definition order).
Make each `#[run]` step a plain `fn` and `await` async work inside it (`await self.load_rates()`): an `async fn` step
is started without waiting for it. `run_capability(name, args, customer_id?)`, `claude_tools(customer_id?)`, and
`claude_tool_use(tool_use, customer_id?)` run them and produce Claude tool definitions and results. SDKs get results
as plain data, objects included (`run_capability_json`). Capabilities written under `capabilities` in the policy
are named after their field.

## Overriding engine functions

Extend `Limitr` with a type and declare the policy with it, or put the function on the policy itself. A function
with an engine function's name runs instead of it, for every call from the host and the engine, and can still call
the engine's version with `self.<name><Limitr>(...)`:

```stof
#[type]
Limitr MyLimitr: {
    list paused: []   // customers to refuse before the engine looks at the call

    fn allow(id: str!, entitlement: str!, value: float | str = 0, event: bool | str | obj = true, cap: Cap | map = null, overhead?: float, force: bool = false) -> bool {
        if (self.paused.contains(id)) return false;
        self.allow<Limitr>(id, entitlement, value, event, cap, overhead, force)
    }
}

MyLimitr policy: {
    credits: { ... }
    plans: { ... }
}
```

Keep the engine function's exact signature (copy it from `src/spec/limitr.stof`): SDKs pass arguments by position.
Prefer the hooks (cost functions, `enabled`, notifications, event handlers, capabilities) when one fits, and
override for what they don't cover.
